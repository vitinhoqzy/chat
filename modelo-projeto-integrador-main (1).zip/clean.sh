clear
echo "Limpando arquivos..."
rm *.aux
rm *.bbl 
rm *.blg 
rm *.brf 
rm *.dvi 
rm *.ilg 
rm *.ind 
rm *.log 
rm *.out 
rm *.nav 
rm *.snm 
rm *.toc 
rm *.idx 
rm *.lof 
rm *.lot 
rm *.snm 
rm *.bcf 
rm *.run.xml 
rm *.vrb,
rm *.fdb_latexmk
rm *.fls
rm *.gz
rm *.upa
clear
echo "Terminado!"
